// public/js/script.js

// Функція, яка викликається при завантаженні сторінки
window.onload = function() {
    // Ваш JavaScript-код тут
    console.log('Скрипт завантажено');
};
